#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int match_line(int fd, char *str);
typedef struct{
  char *strAPesquisar;
  char *fileAPesquisar;
}Argumentos;
void *thread_func(void*args);

int main(int argc, char const *argv[]) {

    Argumentos arguments;
    //Aloca memoria
    arguments.strAPesquisar = malloc(strlen(argv[1])*sizeof(char));
    arguments.fileAPesquisar = malloc(strlen(argv[2])*sizeof(char));

    //Guarda na estrura
    strcpy(arguments.strAPesquisar,argv[1]);
    strcpy(arguments.fileAPesquisar,argv[2]);

    //Inicializa pthread
    pthread_t tid;

    pthread_create(&tid, NULL,thread_func,&arguments);

    pthread_join(tid,NULL);



  return 0;
}

void *thread_func(void*arg){
  //Casting da Estrutura
  Argumentos *args = (Argumentos*)arg;
  int fd , loop=1, *arrayPos, pos = 0, elements_index=0;
  //Abres ficheiro
  fd = open(args->fileAPesquisar, O_RDONLY);
  arrayPos = malloc(sizeof(int));

  while(loop){
    pos = match_line(fd,args->strAPesquisar);
    if (pos==0) {
      loop=0;
    }else{
      arrayPos = realloc(arrayPos,elements_index+1);
      arrayPos[elements_index++]=pos;
    }
  }

  printf("%s :",args->fileAPesquisar);

  for (size_t i = 0; i < elements_index; i++) {
    printf("%d ",arrayPos[i]);
  }
  printf("\n");

  pthread_exit(NULL);

}
