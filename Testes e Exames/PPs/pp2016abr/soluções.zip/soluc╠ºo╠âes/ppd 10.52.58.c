#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int match_line(int fd, char *str);
typedef struct{
  char *strAPesquisar;
  char *fileAPesquisar;
}Argumentos;
void *thread_func(void*args);

int done=0;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int main(int argc, char const *argv[]) {


    //Inicializa pthread e Estrutura
    pthread_t tid[argc-2];
    Argumentos arguments[argc-2];

    for (size_t i = 0; i < argc-2; i++) {
      //Aloca memoria
      arguments[i].strAPesquisar = malloc(strlen(argv[1])*sizeof(char));
      arguments[i].fileAPesquisar = malloc(strlen(argv[2+i])*sizeof(char));

      //Guarda na estrura
      strcpy(arguments[i].strAPesquisar,argv[1]);
      strcpy(arguments[i].fileAPesquisar,argv[2+i]);



      pthread_create(&tid[i], NULL,thread_func,&arguments[i]);
    }
    pthread_mutex_lock(&lock);

    while(done!=3){
        pthread_cond_wait(&cond, &lock);
    }

    pthread_mutex_unlock(&lock);

    pthread_cond_destroy(&cond);
    pthread_mutex_destroy(&lock);

  return 0;
}

void *thread_func(void*arg){


  //Casting da Estrutura
  Argumentos *args = (Argumentos*)arg;
  int fd , loop=1, *arrayPos, pos = 0, elements_index=0, *temp;

  //Abres ficheiro
  fd = open(args->fileAPesquisar, O_RDONLY);
  arrayPos = malloc(50*sizeof(int));

  pthread_mutex_lock(&lock);
  while(loop){
    pos = match_line(fd,args.strAPesquisar);
    if (pos==0) {
      loop=0;
    }else{
      temp = (int*)realloc(arrayPos,(elements_index+1)*sizeof(int));
      //Força a ALLOCAGEM DE memoria
      while (temp==NULL) {
        temp = (int*)realloc(arrayPos,(elements_index+1)*sizeof(int));
      }
      arrayPos = temp;
      arrayPos[elements_index++]=pos;
    }
  }

  for (size_t i = 0; i < elements_index; i++) {
    printf("%s : %d\n",args->fileAPesquisar,arrayPos[i]);
  }


  pthread_mutex_unlock(&lock);

  pthread_mutex_lock(&lock);
  done++;
  pthread_cond_signal(&cond);
  pthread_mutex_unlock(&lock);
  free(temp);
  free(arrayPos);
  pthread_exit(NULL);

}
